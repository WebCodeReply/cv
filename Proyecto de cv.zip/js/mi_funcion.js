function myFunctionDM() {
   var element = document.body;
   element.classList.toggle("darkmode");
}
